package id.co.bca.springtutorial.HelloWorld.model;

import org.springframework.stereotype.Component;

@Component
public interface Employee {
    String salary();
}
